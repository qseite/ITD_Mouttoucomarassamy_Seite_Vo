var searchData=
[
  ['m_5finstance',['m_instance',['../classtsp_1_1heuristic_1_1_a_heuristic.html#a8be1dd6cd9c5a8cd8ed839d46c7cb85f',1,'tsp.heuristic.AHeuristic.m_instance()'],['../classtsp_1_1metaheuristic_1_1_a_metaheuristic.html#aa25dbfb4c96866bce856787dd30352b5',1,'tsp.metaheuristic.AMetaheuristic.m_instance()'],['../classtsp_1_1neighborhood_1_1_a_neighborhood.html#a6429b45bcc40a067c68f677a4754be9c',1,'tsp.neighborhood.ANeighborhood.m_instance()']]],
  ['m_5fname',['m_name',['../classtsp_1_1heuristic_1_1_a_heuristic.html#a909754c0caf21979fa1d3c8bee42c000',1,'tsp.heuristic.AHeuristic.m_name()'],['../classtsp_1_1metaheuristic_1_1_a_metaheuristic.html#a9e4b4a3b7555598bf92d825ada066a75',1,'tsp.metaheuristic.AMetaheuristic.m_name()'],['../classtsp_1_1neighborhood_1_1_a_neighborhood.html#a8b6fb5f32e75265e1fd670a8158066b5',1,'tsp.neighborhood.ANeighborhood.m_name()']]],
  ['m_5fsolution',['m_solution',['../classtsp_1_1heuristic_1_1_a_heuristic.html#a43dda539b2ed7ca67172c97951a2bde9',1,'tsp::heuristic::AHeuristic']]]
];
