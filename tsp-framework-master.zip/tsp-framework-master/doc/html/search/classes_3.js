var searchData=
[
  ['solution',['Solution',['../classtsp_1_1_solution.html',1,'tsp']]]
];
